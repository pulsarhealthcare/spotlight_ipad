
//Index navigation arrays [name,filename]

//Fade text

$('h2').delay(600).animate({opacity:1},500);

$('#main').eq(0).delay(600).animate({opacity:1},700);