
//Index navigation arrays [name,filename]

$('#main').eq(0).delay(600).animate({opacity:1},400);
