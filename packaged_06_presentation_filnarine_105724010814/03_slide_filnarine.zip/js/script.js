
//Index navigation arrays [name,filename]

//Fade text

$('h2').delay(600).animate({opacity:1},600);

$('#main').eq(0).delay(1100).animate({opacity:1},700);
