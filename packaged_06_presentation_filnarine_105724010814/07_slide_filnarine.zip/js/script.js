
//Index navigation arrays [name,filename]

//Fade text

$('#slide_container h2').delay(600).animate({opacity:1},600);
$('#slide_container h3').eq(0).delay(1100).animate({opacity:1},600);
$('#slide_container h4').eq(0).delay(1600).animate({opacity:1},600);
$('#slide_container h3').eq(1).delay(2100).animate({opacity:1},600);
$('#slide_container h4').eq(1).delay(2600).animate({opacity:1},600);

