
//Index navigation arrays [name,filename]

$('h2').delay(600).animate({opacity:1},500);
$('#main').eq(0).delay(600).animate({opacity:1},400);
