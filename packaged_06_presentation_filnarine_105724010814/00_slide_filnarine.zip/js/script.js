
//Index navigation arrays [name,filename]

//Fade text

$('h2').delay(600).animate({opacity:1},600);

$('p').eq(0).delay(1100).animate({opacity:1},600);
$('p').eq(1).delay(1500).animate({opacity:1},600);
$('p').eq(2).delay(1900).animate({opacity:1},600);